﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pract_Camp_5
{
    internal class Camp5_ejercicio2
    {

        //Ejercicio: Calcular un promedio de 3 notas por valor y por referencia

        static void Main(string[] args)
        {
            double n1 = 15, n2 = 18, n3 = 13;

            //llamamos a las librerias donde tenemos los parametros creados

            //Parametro por Valor
            double prom1=LibreriaCamp5.PromedioxValor(n1, n2, n3);
            Console.WriteLine($"Promedio por valor {prom1:f2}");
            Console.WriteLine($"Notas originales {n1}, {n2}, {n3}");


            //Parametro por referencia
            double prom2=LibreriaCamp5.PromedioxReferencia(ref n1 , ref n2, ref n3);
            Console.WriteLine($"Promedio por refreencia {prom2:f2}");
            Console.WriteLine($"Notas originales despues de modificarlas {n1}, {n2}, {n3}");

            Console.ReadKey();
        }
    }
}
