﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pract_Camp_5

{
    internal class LibreriaCamp5
    {
        // Parametro por valor
        public static double PromedioxValor (double n1,  double n2, double n3)
        {
            return (n1 + n2 + n3) / 3; //nos devolvera el promedio sin modificar las variables
        }

        //Parametro por referencia
        public static double PromedioxReferencia (ref double n1, ref double n2, ref double n3)
        {
            n1 = n1 + 1;  //Modificaremos las notas para ver que la variable si se modifica
            n2 = n2 + 1;
            n3 = n3 + 1;
            return (n1+n2+ n3) / 3;
        }
       
    }
}
